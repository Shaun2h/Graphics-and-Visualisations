1. Go to command line, cd to the directory and type `make`
2. To execute: `./a1 swp/<objectname>`
3. To see compiled solution: `./a1soln swp/<objectname>